from dataclasses import dataclass, asdict
import json
from pathlib import Path
import numpy as np

@dataclass
class InversionConfig:
    radius_m: float = 6.0
    current_a: float = 1.0
    tx_height_m: float = 0.0
    rx_height_m: float = 0.5
    response_type: str = "B"
    component: str = "z"
    source_type: str = "circular_loop"
    waveform_type: str = "step_off"
    depth_min_m: float = 1.0
    depth_max_m: float = 200.0
    growth_factor: float = 1.15
    starting_sigma: float = 0.1
    relative_error: float = 0.05
    floor_fraction: float = 0.01
    absolute_floor: float = 1e-15
    max_iterations: int = 35
    warm_start: bool = True

    def validate(self):
        for key in ("radius_m","current_a","depth_min_m","depth_max_m",
                    "growth_factor","starting_sigma","absolute_floor"):
            if getattr(self,key) <= 0: raise ValueError(f"{key} must be positive")
        if self.depth_max_m <= self.depth_min_m: raise ValueError("depth_max_m must exceed depth_min_m")
        if self.growth_factor <= 1: raise ValueError("growth_factor must exceed 1")
        if self.relative_error < 0 or self.floor_fraction < 0: raise ValueError("uncertainty factors cannot be negative")
        if self.max_iterations < 1: raise ValueError("max_iterations must be positive")
        if self.response_type not in ("B","dBdt") or self.component not in ("x","y","z"):
            raise ValueError("Invalid receiver type/component")
        if self.source_type != "circular_loop" or self.waveform_type != "step_off":
            raise ValueError("This tested MVP adapter supports circular_loop + step_off only")
        if self.component != "z":
            raise ValueError("This MVP adapter supports z-component only; other configurations require validation")

    def save(self,path):
        self.validate()
        Path(path).write_text(json.dumps(asdict(self),indent=2))
    @classmethod
    def load(cls,path):
        obj=cls(**json.loads(Path(path).read_text()))
        obj.validate()
        return obj

@dataclass
class SurveyData:
    x_m: np.ndarray
    times_s: np.ndarray
    values_si: np.ndarray
    std_si: np.ndarray | None = None
    active_mask: np.ndarray | None = None

    def validate(self):
        self.x_m=np.asarray(self.x_m,dtype=float).ravel()
        self.times_s=np.asarray(self.times_s,dtype=float).ravel()
        self.values_si=np.asarray(self.values_si,dtype=float)
        if self.values_si.shape != (len(self.x_m),len(self.times_s)):
            raise ValueError("Data matrix must have shape (stations, times)")
        if len(self.x_m)==0 or len(self.times_s)==0: raise ValueError("Empty survey")
        if not (np.isfinite(self.x_m).all() and np.isfinite(self.times_s).all()
                and np.isfinite(self.values_si).all()): raise ValueError("Nonfinite input")
        if np.any(self.times_s<=0) or np.any(np.diff(self.times_s)<=0):
            raise ValueError("Times must be positive and strictly increasing")
        if self.std_si is not None:
            self.std_si=np.asarray(self.std_si,dtype=float)
            if self.std_si.shape!=self.values_si.shape or not np.isfinite(self.std_si).all() or np.any(self.std_si<=0):
                raise ValueError("Invalid uncertainty matrix")
        if self.active_mask is not None:
            self.active_mask=np.asarray(self.active_mask,dtype=bool)
            if self.active_mask.shape!=self.values_si.shape: raise ValueError("Invalid active mask")
            if np.any(self.active_mask.sum(axis=1)==0): raise ValueError("Each station needs active channels")
        return self
