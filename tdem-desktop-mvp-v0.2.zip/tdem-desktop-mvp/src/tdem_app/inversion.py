import numpy as np
from .models import InversionConfig
def layer_thicknesses(cfg):
    h=[cfg.depth_min_m]
    while sum(h)<cfg.depth_max_m:
        h.append(h[-1]*cfg.growth_factor)
        if len(h)>1000: raise ValueError("Too many layers")
    return np.asarray(h)

def uncertainty(obs,cfg,imported=None):
    if imported is not None: return np.asarray(imported,dtype=float)
    return cfg.relative_error*np.abs(obs)+np.maximum(cfg.floor_fraction*np.max(np.abs(obs)),cfg.absolute_floor)

def build_simulation(x,times,cfg):
    cfg.validate()
    import simpeg.electromagnetics.time_domain as tdem
    from simpeg import maps
    from simpeg.electromagnetics.time_domain.simulation_1d import Simulation1DLayered
    source=np.array([x,0.0,cfg.tx_height_m])
    receiver=np.array([x,0.0,cfg.rx_height_m])
    receiver_class=(tdem.receivers.PointMagneticFluxDensity if cfg.response_type=="B"
                    else tdem.receivers.PointMagneticFluxTimeDerivative)
    rx=receiver_class(receiver,times,orientation=cfg.component)
    src=tdem.sources.CircularLoop(receiver_list=[rx],location=source,orientation="z",
                                  waveform=tdem.sources.StepOffWaveform(),
                                  current=cfg.current_a,radius=cfg.radius_m)
    survey=tdem.Survey([src])
    thicknesses=layer_thicknesses(cfg)
    n=len(thicknesses)+1
    sim=Simulation1DLayered(survey=survey,thicknesses=thicknesses,sigmaMap=maps.ExpMap(nP=n))
    return sim,survey,n

def invert_station(x,times,observed,cfg,initial=None,imported_std=None,mask=None):
    from simpeg import data,data_misfit,regularization,optimization,inverse_problem,inversion,directives
    from discretize import TensorMesh
    cfg.validate()
    active=np.ones(len(times),dtype=bool) if mask is None else np.asarray(mask,dtype=bool)
    t=np.asarray(times)[active];d=np.asarray(observed)[active]
    s=uncertainty(observed,cfg,imported_std)[active]
    if not len(t): raise ValueError("No active observations")
    sim,survey,n=build_simulation(x,t,cfg)
    h=layer_thicknesses(cfg)
    reg_mesh=TensorMesh([np.flip(np.r_[h,h[-1]])],"N")
    m0=np.full(n,np.log(cfg.starting_sigma))
    reg=regularization.WeightedLeastSquares(reg_mesh,length_scale_x=10.0,
            reference_model=m0,reference_model_in_smooth=False)
    opt=optimization.InexactGaussNewton(maxIter=cfg.max_iterations,maxIterLS=20,cg_maxiter=20,cg_rtol=1e-3)
    directives_list=[
        directives.UpdatePreconditioner(update_every_iteration=True),
        directives.BetaEstimate_ByEig(beta0_ratio=5),
        directives.BetaSchedule(coolingFactor=2.0,coolingRate=3),
        directives.TargetMisfit(chifact=1.0)]
    dat=data.Data(survey,dobs=d,standard_deviation=s)
    mis=data_misfit.L2DataMisfit(simulation=sim,data=dat)
    problem=inverse_problem.BaseInvProblem(mis,reg,opt)
    inv=inversion.BaseInversion(problem,directives_list)
    start=m0 if initial is None else np.asarray(initial,dtype=float).copy()
    recovered=np.asarray(inv.run(start),dtype=float)
    pred=sim.dpred(recovered)
    phi=float(0.5*np.sum(((pred-d)/s)**2))
    return {"model_log_sigma":recovered,"predicted":pred,"observed":d,"times_s":t,
            "std_si":s,"phi_d":phi,"normalized_misfit":2*phi/len(d),
            "x_m":float(x),"n_active":len(d)}
