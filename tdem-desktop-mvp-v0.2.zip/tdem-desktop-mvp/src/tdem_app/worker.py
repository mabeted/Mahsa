import argparse,json,sys,traceback,os
import numpy as np
from pathlib import Path
from .project_store import ProjectStore
from .inversion import invert_station

def emit(**kw):
    print(json.dumps(kw),flush=True)

def run(project_path):
    store=ProjectStore(project_path)
    cid,cfg,survey=store.latest()
    rid=store.begin_run(cid)
    emit(event="started",run_id=rid,station_count=len(survey.x_m))
    last=None;failed=0
    cancel_file=store.root/"cancel.request"
    cancel_file.unlink(missing_ok=True)
    status="completed"
    try:
        for i,x in enumerate(survey.x_m):
            if cancel_file.exists():
                status="cancelled";break
            try:
                result=invert_station(x,survey.times_s,survey.values_si[i],cfg,
                   last if cfg.warm_start else None,
                   None if survey.std_si is None else survey.std_si[i],
                   None if survey.active_mask is None else survey.active_mask[i])
                target=store.root/"results"/rid/f"station_{i:04d}.npz"
                tmp=target.with_suffix(".tmp")
                with tmp.open("wb") as f:
                    np.savez_compressed(f,**result)
                    f.flush();os.fsync(f.fileno())
                os.replace(tmp,target)
                relative=str(target.relative_to(store.root))
                store.station_status(rid,i,"completed",relative,result["phi_d"])
                last=result["model_log_sigma"]
                emit(event="station_completed",run_id=rid,station_index=i,
                     station_count=len(survey.x_m),normalized_misfit=result["normalized_misfit"],
                     result_path=relative)
            except Exception as e:
                failed+=1
                last=None
                store.station_status(rid,i,"failed",error=str(e))
                emit(event="station_failed",station_index=i,error=str(e))
        if status=="completed" and failed: status="completed_with_failures"
    except BaseException:
        status="failed"
        emit(event="fatal",error=traceback.format_exc())
        raise
    finally:
        store.finish(rid,status)
        emit(event="finished",run_id=rid,status=status,failed=failed)
    return status

def main():
    p=argparse.ArgumentParser()
    p.add_argument("project")
    args=p.parse_args()
    run(args.project)
if __name__=="__main__":main()
