import sqlite3, json, uuid
from datetime import datetime,timezone
from pathlib import Path
from .data_io import save_survey,load_survey
from .models import InversionConfig

DDL = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,name TEXT NOT NULL,created_at TEXT NOT NULL,schema_version INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS surveys(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),data_path TEXT NOT NULL,n_stations INTEGER NOT NULL,n_channels INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS inversion_configs(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),config_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS inversion_runs(id TEXT PRIMARY KEY,config_id TEXT NOT NULL REFERENCES inversion_configs(id),status TEXT NOT NULL,started_at TEXT NOT NULL,finished_at TEXT);
CREATE TABLE IF NOT EXISTS station_results(id TEXT PRIMARY KEY,run_id TEXT NOT NULL REFERENCES inversion_runs(id),station_index INTEGER NOT NULL,status TEXT NOT NULL,result_path TEXT,phi_d REAL,error TEXT,UNIQUE(run_id,station_index));
"""
def now(): return datetime.now(timezone.utc).isoformat()
class ProjectStore:
    def __init__(self,path):
        self.root=Path(path);self.root.mkdir(parents=True,exist_ok=True)
        self.db=self.root/"project.db"
        with self.connect() as c: c.executescript(DDL)
    def connect(self):
        c=sqlite3.connect(self.db,timeout=30)
        c.execute("PRAGMA foreign_keys=ON")
        return c
    def create(self,name,survey,config):
        survey.validate();config.validate()
        pid=str(uuid.uuid4());sid=str(uuid.uuid4());cid=str(uuid.uuid4())
        (self.root/"observations").mkdir(exist_ok=True)
        save_survey(survey,self.root/"observations"/"normalized.npz")
        with self.connect() as c:
            c.execute("INSERT INTO projects VALUES(?,?,?,?)",(pid,name,now(),1))
            c.execute("INSERT INTO surveys VALUES(?,?,?,?,?)",(sid,pid,"observations/normalized.npz",len(survey.x_m),len(survey.times_s)))
            c.execute("INSERT INTO inversion_configs VALUES(?,?,?)",(cid,pid,json.dumps(config.__dict__)))
        return cid
    def latest(self):
        with self.connect() as c:
            r=c.execute("SELECT id,config_json FROM inversion_configs ORDER BY rowid DESC LIMIT 1").fetchone()
            s=c.execute("SELECT data_path FROM surveys ORDER BY rowid DESC LIMIT 1").fetchone()
        if not r or not s: raise ValueError("Project contains no survey/configuration")
        return r[0],InversionConfig(**json.loads(r[1])),load_survey(self.root/s[0])
    def begin_run(self,cid):
        rid=str(uuid.uuid4())
        with self.connect() as c: c.execute("INSERT INTO inversion_runs(id,config_id,status,started_at) VALUES(?,?,?,?)",(rid,cid,"running",now()))
        (self.root/"results"/rid).mkdir(parents=True,exist_ok=True)
        return rid
    def station_status(self,rid,i,status,path=None,phi=None,error=None):
        with self.connect() as c:
            c.execute("INSERT OR REPLACE INTO station_results VALUES(?,?,?,?,?,?,?)",
                      (f"{rid}:{i}",rid,i,status,path,phi,error))
    def finish(self,rid,status):
        with self.connect() as c:
            c.execute("UPDATE inversion_runs SET status=?,finished_at=? WHERE id=?",(status,now(),rid))
