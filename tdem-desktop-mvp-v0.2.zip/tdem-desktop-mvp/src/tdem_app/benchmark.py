import argparse,time,json
from pathlib import Path
import numpy as np
from .models import InversionConfig,SurveyData
from .inversion import build_simulation
from .project_store import ProjectStore
from .worker import run

def generate(stations=50,channels=30):
    cfg=InversionConfig()
    times=np.geomspace(1e-4,1e-2,channels)
    x=np.arange(stations,dtype=float)*10
    values=[]
    for position in x:
        sim,_,n=build_simulation(position,times,cfg)
        # Deterministic smooth lateral variation; valid 1D synthetic stations.
        sigma=0.1*(1+0.2*np.sin(position/100))
        values.append(sim.dpred(np.full(n,np.log(sigma))))
    return SurveyData(x,times,np.asarray(values)).validate(),cfg

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--project",default="benchmark_project")
    p.add_argument("--stations",type=int,default=50)
    p.add_argument("--channels",type=int,default=30)
    p.add_argument("--run",action="store_true",help="Run full inversion; can be slow")
    args=p.parse_args()
    if args.stations<1 or args.channels<2: p.error("Need at least 1 station and 2 channels")
    t=time.perf_counter()
    survey,cfg=generate(args.stations,args.channels)
    store=ProjectStore(args.project);store.create("Synthetic benchmark",survey,cfg)
    print(json.dumps({"event":"generated","stations":args.stations,"channels":args.channels,
                      "observations":args.stations*args.channels,
                      "generation_seconds":round(time.perf_counter()-t,3)}))
    if args.run:
        start=time.perf_counter()
        status=run(args.project)
        print(json.dumps({"event":"benchmark_complete","status":status,
                          "inversion_seconds":round(time.perf_counter()-start,3)}))
if __name__=="__main__":main()
