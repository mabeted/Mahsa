import sys,json
from pathlib import Path
from PySide6.QtCore import QProcess,Qt
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,
    QPushButton,QFileDialog,QLabel,QTextEdit,QSpinBox,QFormLayout,QDoubleSpinBox,
    QMessageBox,QLineEdit,QSplitter)
from .models import InversionConfig
from .data_io import load_profile
from .project_store import ProjectStore

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TDEM Studio — MVP")
        self.resize(1050,700)
        self.project=None;self.process=None
        outer=QWidget();self.setCentralWidget(outer)
        layout=QHBoxLayout(outer)
        left=QWidget();form=QVBoxLayout(left)
        self.path_label=QLabel("No project")
        form.addWidget(self.path_label)
        self.name=QLineEdit("Survey 001");form.addWidget(QLabel("Project name"));form.addWidget(self.name)
        self.radius=QDoubleSpinBox();self.radius.setRange(.01,1e6);self.radius.setValue(6)
        self.current=QDoubleSpinBox();self.current.setRange(.001,1e6);self.current.setValue(1)
        self.max_iter=QSpinBox();self.max_iter.setRange(1,200);self.max_iter.setValue(35)
        settings=QFormLayout();settings.addRow("Loop radius (m)",self.radius)
        settings.addRow("Current (A)",self.current);settings.addRow("Max iterations",self.max_iter)
        form.addLayout(settings)
        b=QPushButton("Import CSV/TXT and create project");b.clicked.connect(self.import_project);form.addWidget(b)
        b=QPushButton("Open project");b.clicked.connect(self.open_project);form.addWidget(b)
        self.run_btn=QPushButton("Run inversion");self.run_btn.clicked.connect(self.run_inversion);form.addWidget(self.run_btn)
        b=QPushButton("Request cancellation");b.clicked.connect(self.cancel);form.addWidget(b)
        b=QPushButton("View results");b.clicked.connect(self.plot_results);form.addWidget(b)
        form.addStretch()
        self.log=QTextEdit();self.log.setReadOnly(True)
        split=QSplitter();split.addWidget(left);split.addWidget(self.log)
        split.setStretchFactor(1,3);layout.addWidget(split)
        self.statusBar().showMessage("Ready")

    def message(self,s):self.log.append(str(s))
    def import_project(self):
        t,_=QFileDialog.getOpenFileName(self,"Time channels",filter="Text (*.txt *.csv);;All files (*)")
        if not t:return
        p,_=QFileDialog.getOpenFileName(self,"Profile CSV",filter="CSV (*.csv)")
        if not p:return
        dest=QFileDialog.getExistingDirectory(self,"Select empty project folder")
        if not dest:return
        try:
            survey=load_profile(t,p)
            cfg=InversionConfig(radius_m=self.radius.value(),current_a=self.current.value(),max_iterations=self.max_iter.value())
            store=ProjectStore(dest)
            store.create(self.name.text(),survey,cfg)
            self.project=dest;self.path_label.setText(dest)
            self.message(f"Imported {len(survey.x_m)} stations × {len(survey.times_s)} channels")
        except Exception as e:QMessageBox.critical(self,"Import error",str(e))
    def open_project(self):
        dest=QFileDialog.getExistingDirectory(self,"Open project folder")
        if not dest:return
        try:
            _,cfg,survey=ProjectStore(dest).latest()
            self.project=dest;self.path_label.setText(dest)
            self.radius.setValue(cfg.radius_m);self.current.setValue(cfg.current_a);self.max_iter.setValue(cfg.max_iterations)
            self.message(f"Opened {len(survey.x_m)} stations")
        except Exception as e:QMessageBox.critical(self,"Project error",str(e))
    def run_inversion(self):
        if not self.project:
            QMessageBox.warning(self,"No project","Import or open a project first");return
        if self.process and self.process.state()!=QProcess.NotRunning:return
        self.process=QProcess(self)
        self.process.setProgram(sys.executable)
        self.process.setArguments(["-m","tdem_app.worker",self.project])
        self.process.readyReadStandardOutput.connect(self.read_output)
        self.process.readyReadStandardError.connect(self.read_errors)
        self.process.finished.connect(lambda *_:self.run_btn.setEnabled(True))
        self.run_btn.setEnabled(False)
        self.process.start()
    def read_output(self):
        for line in bytes(self.process.readAllStandardOutput()).decode(errors="replace").splitlines():
            try:
                event=json.loads(line)
                self.message(event)
                if event.get("event")=="station_completed":
                    self.statusBar().showMessage(f"Completed station {event['station_index']+1}/{event['station_count']}")
            except json.JSONDecodeError:self.message(line)
    def read_errors(self):self.message(bytes(self.process.readAllStandardError()).decode(errors="replace"))
    def cancel(self):
        if self.project and self.process and self.process.state()!=QProcess.NotRunning:
            (Path(self.project)/"cancel.request").touch()
            self.message("Cancellation requested after current station")
    def plot_results(self):
        if not self.project:
            return
        try:
            from .visualization import load_latest_results, plot_pseudosection, plot_station_fit, plot_residuals
            from matplotlib.figure import Figure
            from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
            from PySide6.QtWidgets import QDialog, QComboBox
            cfg, survey, results = load_latest_results(self.project)
            dialog = QDialog(self)
            dialog.setWindowTitle("Inversion Results — QC and Pseudo-section")
            dialog.resize(1100, 780)
            layout = QVBoxLayout(dialog)
            chooser = QComboBox()
            for idx in sorted(results):
                chooser.addItem(f"Station {idx + 1} — x={survey.x_m[idx]:g} m", idx)
            layout.addWidget(chooser)
            fig = Figure(figsize=(11, 8), constrained_layout=True)
            canvas = FigureCanvasQTAgg(fig)
            layout.addWidget(canvas)
            def redraw():
                fig.clear()
                upper = fig.add_subplot(211)
                mesh = plot_pseudosection(upper, cfg, survey, results)
                fig.colorbar(mesh, ax=upper, label="log10 conductivity (S/m)")
                lower_left = fig.add_subplot(223)
                lower_right = fig.add_subplot(224)
                record = results[chooser.currentData()]
                plot_station_fit(lower_left, record)
                plot_residuals(lower_right, record)
                canvas.draw_idle()
            chooser.currentIndexChanged.connect(redraw)
            redraw()
            dialog.exec()
        except Exception as exc:
            QMessageBox.critical(self, "Results error", str(exc))
    def closeEvent(self,event):
        if self.process and self.process.state()!=QProcess.NotRunning:
            QMessageBox.warning(self,"Inversion running","Request cancellation and wait for the worker to finish.")
            event.ignore();return
        super().closeEvent(event)

def main():
    app=QApplication(sys.argv)
    win=MainWindow();win.show()
    return app.exec()
if __name__=="__main__":sys.exit(main())
