import numpy as np
from .models import SurveyData

def load_profile(times_path, profile_path, std_path=None):
    times=np.loadtxt(times_path,dtype=float).reshape(-1)
    raw=np.loadtxt(profile_path,delimiter=",",skiprows=1,ndmin=2)
    std=None if std_path is None else np.loadtxt(std_path,delimiter=",",skiprows=1,ndmin=2)
    if std is not None:
        if std.shape != raw.shape: raise ValueError("Uncertainty CSV must match profile dimensions")
        if not np.allclose(std[:,0],raw[:,0]): raise ValueError("Uncertainty station positions mismatch")
        std=std[:,1:]
    return SurveyData(raw[:,0],times,raw[:,1:],std).validate()

def save_survey(survey,path):
    survey.validate()
    np.savez_compressed(path,x_m=survey.x_m,times_s=survey.times_s,
                        values_si=survey.values_si,
                        std_si=survey.std_si if survey.std_si is not None else np.array([]),
                        active_mask=survey.active_mask if survey.active_mask is not None else np.array([]))

def load_survey(path):
    with np.load(path,allow_pickle=False) as f:
        std=f["std_si"]; mask=f["active_mask"]
        return SurveyData(f["x_m"],f["times_s"],f["values_si"],
                          std if std.size else None,mask if mask.size else None).validate()
