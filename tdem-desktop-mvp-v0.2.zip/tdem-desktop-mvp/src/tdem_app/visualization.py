"""Result loading and scientific plots; independent of Qt."""
import numpy as np
from .project_store import ProjectStore
from .inversion import layer_thicknesses

def load_latest_results(project):
    store = ProjectStore(project)
    with store.connect() as con:
        run = con.execute("SELECT id FROM inversion_runs ORDER BY started_at DESC LIMIT 1").fetchone()
        if run is None:
            raise ValueError("No inversion run found")
        rows = con.execute(
            "SELECT station_index,result_path FROM station_results "
            "WHERE run_id=? AND status='completed' ORDER BY station_index", (run[0],)
        ).fetchall()
    if not rows:
        raise ValueError("No completed station results")
    _, config, survey = store.latest()
    results = {}
    for index, path in rows:
        target = (store.root / path).resolve()
        if not target.is_relative_to(store.root.resolve()):
            raise ValueError("Result path escapes project directory")
        with np.load(target, allow_pickle=False) as data:
            results[index] = {k: data[k].copy() for k in data.files}
    return config, survey, results

def depth_edges(config, display_depth=None):
    finite = layer_thicknesses(config)
    last = finite.sum()
    bottom = float(display_depth) if display_depth is not None else max(last + finite[-1], config.depth_max_m * 1.25)
    if bottom <= last:
        raise ValueError("Display depth must extend below the last finite layer")
    return np.r_[0., np.cumsum(finite), bottom]

def pseudosection_arrays(config, survey, results, display_depth=None):
    """Return station coordinates, depth edges and masked log10 conductivity.

    Missing/failed stations remain masked; they are not silently interpolated.
    """
    edges = depth_edges(config, display_depth)
    values = np.ma.masked_all((len(edges)-1, len(survey.x_m)), dtype=float)
    for i, record in results.items():
        model = np.asarray(record["model_log_sigma"], dtype=float)
        if model.shape != (len(edges)-1,):
            raise ValueError(f"Station {i} has incompatible layer count")
        values[:, i] = model / np.log(10)
    return np.asarray(survey.x_m), edges, values

def plot_pseudosection(ax, config, survey, results):
    x, edges, values = pseudosection_arrays(config, survey, results)
    if len(x) > 1 and np.any(np.diff(x) <= 0):
        raise ValueError("Station x coordinates must be strictly increasing for a pseudo-section")
    if len(x) == 1:
        dx = 5.0
        x_edges = np.array([x[0]-dx, x[0]+dx])
    else:
        mids = (x[:-1]+x[1:])/2
        x_edges = np.r_[x[0]-(mids[0]-x[0]), mids, x[-1]+(x[-1]-mids[-1])]
    mesh = ax.pcolormesh(x_edges, edges, values, shading="flat", cmap="viridis")
    ax.invert_yaxis()
    ax.set(xlabel="Distance x (m)", ylabel="Depth (m)", title="Recovered 1D conductivity pseudo-section")
    return mesh

def plot_station_fit(ax, record):
    t = np.asarray(record["times_s"])
    observed = np.asarray(record["observed"])
    predicted = np.asarray(record["predicted"])
    ax.plot(t, observed, "o-", label="Observed")
    ax.plot(t, predicted, "--", label="Predicted")
    ax.set_xscale("log")
    ax.set(xlabel="Time (s)", ylabel="Response (SI)", title="Signed observed / predicted response")
    ax.grid(True, alpha=.3)
    ax.legend()

def plot_residuals(ax, record):
    residual = (np.asarray(record["predicted"])-np.asarray(record["observed"]))/np.asarray(record["std_si"])
    ax.semilogx(record["times_s"], residual, "o-")
    ax.axhline(0, color="gray", linewidth=1)
    ax.set(xlabel="Time (s)", ylabel="Normalized residual", title="(Predicted - observed) / uncertainty")
    ax.grid(True, alpha=.3)
