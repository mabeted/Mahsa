import numpy as np
import pytest
from tdem_app.models import SurveyData, InversionConfig
from tdem_app.visualization import depth_edges, pseudosection_arrays, plot_pseudosection

def test_pseudosection_preserves_failed_station_mask():
    cfg = InversionConfig()
    survey = SurveyData(np.array([0.,10.,20.]),np.array([.001,.002]),np.ones((3,2))).validate()
    n = len(depth_edges(cfg))-1
    results = {0: {"model_log_sigma":np.log(np.full(n,.1))},
               2: {"model_log_sigma":np.log(np.full(n,.01))}}
    x,edges,values = pseudosection_arrays(cfg,survey,results)
    assert values.shape == (n,3)
    assert np.all(np.ma.getmaskarray(values)[:,1])
    assert np.allclose(values[:,0],-1)
    assert np.allclose(values[:,2],-2)

def test_invalid_layer_count_rejected():
    cfg=InversionConfig()
    survey=SurveyData(np.array([0.]),np.array([.001]),np.ones((1,1))).validate()
    with pytest.raises(ValueError,match="layer count"):
        pseudosection_arrays(cfg,survey,{0:{"model_log_sigma":np.array([0.])}})

def test_plot_smoke():
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib.figure import Figure
    cfg=InversionConfig()
    survey=SurveyData(np.array([0.,10.]),np.array([.001]),np.ones((2,1))).validate()
    n=len(depth_edges(cfg))-1
    fig=Figure()
    ax=fig.add_subplot(111)
    plot_pseudosection(ax,cfg,survey,{0:{"model_log_sigma":np.zeros(n)}})
