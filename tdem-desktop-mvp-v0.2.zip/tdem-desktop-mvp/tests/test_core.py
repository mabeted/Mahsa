import numpy as np
import pytest
from tdem_app.models import SurveyData,InversionConfig
from tdem_app.inversion import layer_thicknesses,uncertainty
from tdem_app.project_store import ProjectStore

def test_layer_parameterization():
    cfg=InversionConfig()
    h=layer_thicknesses(cfg)
    assert len(h)>1 and h.sum()>=cfg.depth_max_m
    assert np.all(np.diff(h)>0)

def test_uncertainty():
    cfg=InversionConfig()
    s=uncertainty(np.zeros(4),cfg)
    assert np.all(s>0)
    assert np.allclose(uncertainty(np.ones(2),cfg,np.array([.1,.2])),[.1,.2])

def test_survey_validation():
    with pytest.raises(ValueError):
        SurveyData(np.array([0]),np.array([.1,.05]),np.ones((1,2))).validate()

def test_project_roundtrip(tmp_path):
    survey=SurveyData(np.array([0.,10.]),np.array([.001,.002]),np.ones((2,2))).validate()
    store=ProjectStore(tmp_path)
    store.create("test",survey,InversionConfig())
    _,cfg,loaded=store.latest()
    assert cfg.radius_m==6 and np.array_equal(loaded.values_si,survey.values_si)
