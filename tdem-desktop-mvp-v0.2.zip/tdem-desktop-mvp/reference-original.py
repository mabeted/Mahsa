"""
SimPEG: N-sounding 1D TDEM inversions -> PSEUDOSECTION (x vs depth)

INPUT FILES (YOU PROVIDE):
1) times.txt   : one column, nt rows, time channels in seconds
2) profile.csv : CSV with header.
                First column = x (m)
                Remaining nt columns = Bz(t) at each time channel (Tesla)

Example:
times.txt
  1e-4
  2e-4
  ...
profile.csv
  x,Bz_t1,Bz_t2,...,Bz_tnt
  0, 2e-9, 1.8e-9, ...
  10, ...
  ...

OUTPUT:
- QC plots for 3 stations (first/middle/last)
- Pseudo-section heatmap of log10 conductivity vs x and depth
"""

import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

import simpeg.electromagnetics.time_domain as tdem
from simpeg import (
    maps,
    data,
    data_misfit,
    regularization,
    optimization,
    inverse_problem,
    inversion,
    directives,
)
from discretize import TensorMesh

mpl.rcParams.update({"font.size": 13})


# =============================================================================
# 0) FILE PATHS (EDIT THESE)
# =============================================================================
times_file = r"times.txt"
data_file  = r"profile.csv"


# =============================================================================
# 1) LOAD INPUT DATA
# =============================================================================
times = np.loadtxt(times_file).astype(float).ravel()  # (nt,)

# CSV: first column = x, remaining columns = Bz(t)
raw = np.loadtxt(data_file, delimiter=",", skiprows=1)
x_locations = raw[:, 0].astype(float)                # (n_sounding,)
dobs_all = raw[:, 1:].astype(float)                  # (n_sounding, nt)

nt = times.size
n_sounding = x_locations.size

if dobs_all.shape[1] != nt:
    raise ValueError(
        f"Mismatch: profile has nt={dobs_all.shape[1]} time columns "
        f"but times.txt has nt={nt} rows."
    )

print(f"Loaded n_sounding={n_sounding}, nt={nt}")
print(f"x: {x_locations.min():.1f} to {x_locations.max():.1f} m")
print(f"t: {times.min():.2e} to {times.max():.2e} s")

# Quick look at station 0
plt.figure(figsize=(5, 4))
plt.loglog(times, np.abs(dobs_all[0, :]), "k-o")
plt.grid(which="both")
plt.xlabel("Time (s)")
plt.ylabel(r"$|B_z|$ (T)")
plt.title("Observed data (station 0)")
plt.show()


# =============================================================================
# 2) SURVEY GEOMETRY (GROUND-BASED SQUID-TDEM CENTRAL LOOP)
# =============================================================================
source_orientation = "z"
receiver_orientation = "z"

source_current = 1.0   # A
source_radius = 6.0    # m

z_tx = 0.0             # loop on ground
z_rx = 0.5             # SQUID height (m) above ground at loop center

waveform = tdem.sources.StepOffWaveform()  # step-off (square shutoff)


# =============================================================================
# 3) 1D LAYERED MODEL PARAMETERIZATION (SAME FOR ALL SOUNDINGS)
# =============================================================================
depth_min = 1.0
depth_max = 200.0
geometric_factor = 1.15

layer_thicknesses = [depth_min]
while np.sum(layer_thicknesses) < depth_max:
    layer_thicknesses.append(geometric_factor * layer_thicknesses[-1])

n_layers = len(layer_thicknesses) + 1  # REQUIRED by Simulation1DLayered
sigma_map = maps.ExpMap(nP=n_layers)   # model m = log(sigma)

m0 = np.log(1e-1 * np.ones(n_layers))  # starting log conductivity
mref = m0.copy()

# Regularization mesh (1D)
h_full = np.r_[layer_thicknesses, layer_thicknesses[-1]]
h_full = np.flipud(h_full)
reg_mesh = TensorMesh([h_full], "N")


# =============================================================================
# 4) INVERSION SETTINGS (L2 SMOOTH)
# =============================================================================
reg = regularization.WeightedLeastSquares(
    reg_mesh,
    length_scale_x=10.0,
    reference_model=mref,
    reference_model_in_smooth=False,
)

opt = optimization.InexactGaussNewton(
    maxIter=35, maxIterLS=20, cg_maxiter=20, cg_rtol=1e-3
)

directive_list = [
    directives.UpdatePreconditioner(update_every_iteration=True),
    directives.BetaEstimate_ByEig(beta0_ratio=5),
    directives.BetaSchedule(coolingFactor=2.0, coolingRate=3),
    directives.TargetMisfit(chifact=1.0),
]

# Uncertainty model
rel_err = 0.05      # 5% relative
floor_frac = 0.01   # +1% of max(|dobs|) per sounding as floor


# =============================================================================
# 5) VERSION-SAFE Simulation1DLayered ACCESS
# =============================================================================
try:
    Simulation1DLayered = tdem.simulation_1d.Simulation1DLayered
except Exception:
    from simpeg.electromagnetics.time_domain.simulation_1d import Simulation1DLayered


# =============================================================================
# 6) RUN INVERSION FOR EACH SOUNDING
# =============================================================================
models_rec = np.zeros((n_sounding, n_layers), dtype=float)   # recovered log(sigma)
dpred_all = np.zeros((n_sounding, nt), dtype=float)

for i, x0 in enumerate(x_locations):

    # Survey at this x station
    src_loc = np.array([x0, 0.0, z_tx])
    rx_loc = np.array([x0, 0.0, z_rx])

    rx = tdem.receivers.PointMagneticFluxDensity(
        rx_loc, times, orientation=receiver_orientation
    )

    src = tdem.sources.CircularLoop(
        receiver_list=[rx],
        location=src_loc,
        orientation=source_orientation,
        waveform=waveform,
        current=source_current,
        radius=source_radius,
    )

    survey = tdem.Survey([src])

    # Data + uncertainties at this station
    dobs_i = np.asarray(dobs_all[i, :]).ravel()
    maxabs = np.max(np.abs(dobs_i)) if np.max(np.abs(dobs_i)) > 0 else 1.0
    floor = floor_frac * maxabs

    std_i = rel_err * np.abs(dobs_i) + floor
    std_i[std_i == 0] = rel_err * 1e-12  # avoid zeros

    data_obj = data.Data(survey, dobs=dobs_i, standard_deviation=std_i)

    # Simulation
    sim = Simulation1DLayered(
        survey=survey,
        thicknesses=layer_thicknesses,
        sigmaMap=sigma_map,
    )

    # Inversion
    dmis = data_misfit.L2DataMisfit(simulation=sim, data=data_obj)
    inv_prob = inverse_problem.BaseInvProblem(dmis, reg, opt)
    inv = inversion.BaseInversion(inv_prob, directive_list)

    # Warm-start from previous station
    mstart = models_rec[i - 1, :] if i > 0 else m0

    mrec = inv.run(mstart)

    models_rec[i, :] = mrec
    dpred_all[i, :] = sim.dpred(mrec)

    print(f"[{i+1}/{n_sounding}] x={x0:.1f} m done")


# =============================================================================
# 7) QC: PLOT FIT FOR FIRST / MIDDLE / LAST
# =============================================================================
for idx in [0, n_sounding // 2, n_sounding - 1]:
    plt.figure(figsize=(5, 4))
    plt.loglog(times, np.abs(dobs_all[idx, :]), "k-o", label="Observed")
    plt.loglog(times, np.abs(dpred_all[idx, :]), "b-o", label="Predicted")
    plt.grid(which="both")
    plt.xlabel("Time (s)")
    plt.ylabel(r"$|B_z|$ (T)")
    plt.title(f"Fit at x={x_locations[idx]:.1f} m")
    plt.legend()
    plt.show()


# =============================================================================
# 8) PSEUDOSECTION PLOT: log10 conductivity (S/m)
# =============================================================================
sigma_rec = np.exp(models_rec)  # (n_sounding, n_layers)

# depth midpoints
z_edges = np.r_[0.0, np.cumsum(np.r_[layer_thicknesses, layer_thicknesses[-1]])]
z_mid = 0.5 * (z_edges[:-1] + z_edges[1:])  # (n_layers,)

X, Z = np.meshgrid(x_locations, z_mid)

plt.figure(figsize=(11, 4.5))
plt.pcolormesh(X, Z, np.log10(sigma_rec.T), shading="auto")
plt.gca().invert_yaxis()
plt.xlabel("Distance x (m)")
plt.ylabel("Depth (m)")
plt.title("Pseudo-section: log10 Conductivity (S/m) from 1D inversions")
plt.colorbar(label="log10(S/m)")
plt.show()
